import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

class FilePickerWidget extends StatefulWidget {
  const FilePickerWidget({Key? key, this.test = false}) : super(key: key);
  final bool test;

  @override
  _FilePickerWidgetState createState() => _FilePickerWidgetState();
}

class _FilePickerWidgetState extends State<FilePickerWidget> {
  List<PlatformFile> pickedFiles = [];
  bool cancelled = false;

  Future<void> pickFile() async {
    print('Picking file');
    // try {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'png', 'pdf'],
    );

    if (result != null && result.files.isNotEmpty) {
      setState(() {
        pickedFiles.addAll(result.files);
      });
    } else {
      // User canceled the picker
      setState(() {
        cancelled = true;
      });
    }

    // } catch (e) {
    //   setState(() {
    //     pickedFileName = "Error picking file";
    //   });
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (cancelled) Text('Action cancelled'),
          ListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: pickedFiles
                .map((each) => Column(
                      children: [
                        if (each.name.contains('.jpg') ||
                            each.name.contains('.png'))
                          Builder(builder: (context) {
                            // if (widget.test) {
                            //   return Image.memory(
                            //     each.toFile().readAsBytesSync(),
                            //     width: 40,
                            //     height: 50,
                            //   );
                            // }
                            return Image.file(
                              each.toFile(),
                              width: 40,
                              height: 50,
                            );
                          }),
                        Text(key: ValueKey('name:${each.name}'), each.name),
                        Text(each.size.toString())
                      ],
                    ))
                .toList(),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            key: const Key('pickFileButton'),
            onPressed: pickFile,
            child: const Text("Pick a File"),
          ),
        ],
      ),
    );
  }
}

extension on PlatformFile {
  File toFile() => File(
        xFile.path,
      );
}
