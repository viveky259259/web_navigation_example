import 'package:flutter/material.dart';
import 'package:flutter_tests/api_service.dart';
import 'package:flutter_tests/file_picker_widget.dart';
import 'package:get_it/get_it.dart';
import 'package:http/http.dart' as http;

late ApiService apiService;
final GetIt getIt = GetIt.instance;
void main() {
  apiService = ApiService('https://jsonplaceholder.typicode.com');
  getIt.registerSingleton<ApiService>(apiService);
  runApp(MaterialApp(
    home: FilePickerWidget(),
  ));
}

class ApiWidget extends StatefulWidget {
  const ApiWidget({Key? key}) : super(key: key);

  @override
  _ApiWidgetState createState() => _ApiWidgetState();
}

class _ApiWidgetState extends State<ApiWidget> {
  String? data;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response = await getIt.get<ApiService>().get('/posts/1');
      print('repose');
      if (response.statusCode == 200) {
        print('success');
        setState(() {
          data = response.body;
          isLoading = false;
        });
      } else {
        print('failure');
        setState(() {
          data = 'Error: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        data = 'Error: $e';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const CircularProgressIndicator();
    }
    return Text(data ?? 'Error');
  }
}


