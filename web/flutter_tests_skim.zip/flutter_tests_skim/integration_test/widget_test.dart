import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_tests/api_service.dart';
import 'package:flutter_tests/main.dart';
import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:integration_test/integration_test.dart';
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    HttpOverrides.global = MyHttpOverrides(); // Apply custom overrides
  });
  testWidgets('Test actual API call in widget', (WidgetTester tester) async {
    // The actual API endpoint
    // Build the widget with the actual API URL
    getIt.registerSingleton(ApiService('https://jsonplaceholder.typicode.com'));
    await tester.pumpWidget(
      MaterialApp(
        home: ApiWidget(),
      ),
    );

    // Verify initial loading state
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    expect(find.textContaining('Error'), findsNothing);
    await tester.pump(Duration(seconds: 4));
    // Wait for the API call to complete
    await tester.pumpAndSettle();

    // Verify the widget displays fetched data (or error message)
    expect(find.byType(CircularProgressIndicator), findsNothing);
    expect(find.textContaining('Error'), findsNothing); // Ensure no errors
    expect(find.textContaining('userId'),
        findsOneWidget); // Verify part of the response
  });
}




class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port) => true;
  }
}