// import 'package:flutter_driver/driver_extension.dart';
import 'package:integration_test/integration_test_driver.dart';

Future<void> main(){
  // enableFlutterDriverExtension();
  return integrationDriver();
}