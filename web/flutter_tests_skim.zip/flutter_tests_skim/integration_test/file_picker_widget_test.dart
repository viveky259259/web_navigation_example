import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_tests/file_picker_widget.dart';
import 'package:file_picker/file_picker.dart';
import 'package:integration_test/integration_test.dart';

final fileByte = [104, 101, 108, 108, 111, 32, 86, 105, 118, 101, 107];

class MockFilePicker extends FilePicker {
  final String path;

  MockFilePicker(this.path);

  static void registerWith() {
    // FOR MACOS only
    FilePicker.platform = FilePickerMacOS();
  }

  @override
  Future<FilePickerResult?> pickFiles({
    String? dialogTitle,
    String? initialDirectory,
    FileType type = FileType.any,
    List<String>? allowedExtensions,
    Function(FilePickerStatus)? onFileLoading,
    bool allowCompression = true,
    int compressionQuality = 30,
    bool allowMultiple = false,
    bool withData = false,
    bool withReadStream = false,
    bool lockParentWindow = false,
    bool readSequential = false,
  }) async {
    print('mock file');

    // // FOR web
    return FilePickerResult([
      PlatformFile(
          name: path.split('/').last,
          path: path,
          bytes: Uint8List.fromList(fileByte),
          size: fileByte.length)
    ]);

    // FOR MACOS
    final actualFile = await rootBundle.load(path);
    print('actualFile: ${actualFile.buffer.asUint8List()}');
    // throw Exception(actualFile.toString());
    final file = File('tempfile${path.split('.').last}');

    file.writeAsBytesSync(actualFile.buffer.asUint8List());
    file.createSync();

    return FilePickerResult([
      PlatformFile(
          name: path.split('/').last,
          path: file.path,
          bytes: file.readAsBytesSync(),
          size: file.lengthSync())
    ]);
  }
}

void main() async {
  // final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized()
  // as IntegrationTestWidgetsFlutterBinding;
  // await integrationDriver(
  // onScreenshot: (String screenshotName, List<int> screenshotBytes, [Map<String, Object?>? args]) async {
  //   final File image = File('$screenshotName.png');
  //   image.writeAsBytesSync(screenshotBytes);
  //   // Return false if the screenshot is invalid.
  //   return true;
  // },
  // );
  // late IntegrationTestWidgetsFlutterBinding binding;
  setUpAll(() {
    // binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  });
  // testWidgets('should display selected file name when a file is picked: TDS',
  //     (WidgetTester tester) async {
  //   FilePicker.platform = MockFilePicker('assets/images/TDS.jpg');
  //   // Arrange
  //
  //   // Act
  //   // test widget intializer
  //   TestWidgetsFlutterBinding.ensureInitialized();
  //   // await tester.runAsync(() async {
  //   await tester.pumpWidget(MaterialApp(
  //     home: FilePickerWidget(
  //       test: true,
  //     ), // Ensure your widget uses the mock
  //   ));
  //
  //   expect(find.text('Pick a File'), findsOneWidget);
  //
  //   await tester.tap(find.byKey(const Key('pickFileButton')));
  //   await tester.pumpAndSettle();
  //
  //   await tester.pumpAndSettle(Duration(seconds: 4));
  //   // Assert
  //   expect(find.text('TDS.jpg'), findsOneWidget);
  //   await tester.tap(find.byKey(const Key('pickFileButton')));
  //   await tester.pumpAndSettle();
  //   await tester.pumpAndSettle(Duration(seconds: 2));
  //   expect(find.text('TDS.jpg'), findsExactly(2));
  // });

  testWidgets(
      'should display selected file name when a file is picked l3 Testing',
      (WidgetTester tester) async {
    // Arrange
    FilePicker.platform = MockFilePicker('assets/l3_testing_guide.pdf');
    // Act
    // test widget intializer
    // TestWidgetsFlutterBinding.ensureInitialized();

    // await tester.runAsync(() async {
    await tester.pumpWidget(MaterialApp(
      home: FilePickerWidget(
        test: true,
      ), // Ensure your widget uses the mock
    ));
    final binding = IntegrationTestWidgetsFlutterBinding.instance;
    //
    // if (binding.runtimeType == IntegrationTestWidgetsFlutterBinding) {
    //   try {


    //     print('took screenshot');
    //     print(ss.length);
    //   } catch (e) {
    //     print('ss');
    //     print(e);
    //   }
    // } else {
    //   print('fata');
    // }
    print(binding.runtimeType);
    expect(find.text('Pick a File'), findsOneWidget);
    final item1Key = ValueKey('name:l3_testing_guide.pdf');
    expect(find.byKey(item1Key), findsNothing);
    await tester.tap(find.byKey(const Key('pickFileButton')));
    await tester.pumpAndSettle();

    await tester.pumpAndSettle(Duration(seconds: 4));
    // Assert
    await (IntegrationTestWidgetsFlutterBinding.instance)
        .takeScreenshot('L3-1-1');
    expect(find.text('l3_testing_guide.pdf'), findsOneWidget);
    // await binding.takeScreenshot('0-home');
    await tester.tap(find.byKey(const Key('pickFileButton')));
    expect(find.byKey(item1Key), findsOneWidget);
    final textwidget = tester.widget<Text>(find.byKey(item1Key));
    expect(textwidget.data, 'l3_testing_guide.pdf');
    await tester.pumpAndSettle();
    await (IntegrationTestWidgetsFlutterBinding.instance)
        .takeScreenshot('L3-1-2');
    // await tester.pumpAndSettle();
    // await tester.pumpAndSettle(Duration(seconds: 2));
    // expect(find.text('l3_testing_guide.pdf'), findsExactly(2));
  });

  testWidgets(
      'should display selected file name when a file is picked l3 Testing1',
      (WidgetTester tester) async {
    // Arrange
    FilePicker.platform = MockFilePicker('l3_testing_guide.pdf');
    // Act
    // test widget intializer
    // TestWidgetsFlutterBinding.ensureInitialized();
    // await tester.runAsync(() async {
    await tester.pumpWidget(MaterialApp(
      home: FilePickerWidget(
        test: true,
      ), // Ensure your widget uses the mock
    ));

    expect(find.text('Pick a File'), findsOneWidget);

    await tester.tap(find.byKey(const Key('pickFileButton')));
    await tester.pumpAndSettle();

    // binding.takeScreenshot('screenshotName.png');
    await tester.pumpAndSettle(Duration(seconds: 4));
    await (IntegrationTestWidgetsFlutterBinding.instance)
        .takeScreenshot('L3-2-1');
    // Assert
    expect(find.text('l3_testing_guide.pdf'), findsOneWidget);
    await tester.tap(find.byKey(const Key('pickFileButton')));
    await tester.pumpAndSettle();
    await tester.pumpAndSettle(Duration(seconds: 2));
    expect(find.text('l3_testing_guide.pdf'), findsExactly(2));
    await (IntegrationTestWidgetsFlutterBinding.instance)
        .takeScreenshot('L3-2-2');
  });
  // });

  // testWidgets(
  //     'should display selected file name when a file is picked hello.txt',
  //     (WidgetTester tester) async {
  //   // Arrange
  //   FilePicker.platform = MockFilePicker('assets/hello.txt');
  //   // Act
  //   // test widget intializer
  //   TestWidgetsFlutterBinding.ensureInitialized();
  //   // await tester.runAsync(() async {
  //   await tester.pumpWidget(MaterialApp(
  //     home: FilePickerWidget(
  //       test: true,
  //     ), // Ensure your widget uses the mock
  //   ));
  //
  //   expect(find.text('Pick a File'), findsOneWidget);
  //
  //   await tester.tap(find.byKey(const Key('pickFileButton')));
  //   await tester.pumpAndSettle();
  //
  //   await tester.pumpAndSettle(Duration(seconds: 4));
  //   // Assert
  //   expect(find.text('hello.txt'), findsOneWidget);
  //   await tester.tap(find.byKey(const Key('pickFileButton')));
  //   await tester.pumpAndSettle();
  //   await tester.pumpAndSettle(Duration(seconds: 2));
  //   expect(find.text('hello.txt'), findsExactly(2));
  // });
}
