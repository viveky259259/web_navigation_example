import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:integration_test/integration_test.dart';
import 'package:integration_test/integration_test_driver_extended.dart';

import './file_picker_widget_test.dart' as test;

// import 'package:flutter_driver/flutter_driver.dart';
// import 'package:flutter_driver/driver_extension.dart';

void main() async {
  // enableFlutterDriverExtension();
  IntegrationTestWidgetsFlutterBinding.ensureInitialized()
      as IntegrationTestWidgetsFlutterBinding;
  // try {
  //   final binding = IntegrationTestWidgetsFlutterBinding.instance;
  //   print(binding);
  // } catch (_) {
  //   IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  // }

  if (kIsWeb) {
    print('Platform:web');
  } else {
    print('Platform: ${Platform.operatingSystem}');
    await integrationDriver(
      onScreenshot: (String screenshotName, List<int> screenshotBytes,
          [Map<String, Object?>? args]) async {
        final File image = File('$screenshotName.png');
        image.writeAsBytesSync(screenshotBytes);
        // Return false if the screenshot is invalid.
        return true;
      },
    );
  }

  test.main();
}
